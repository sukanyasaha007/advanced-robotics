from gym.envs.registration import register

register(
    id='mountaincar5302-v0',
    entry_point='gym_mountaincar.envs:MountainCarEnv'
)
